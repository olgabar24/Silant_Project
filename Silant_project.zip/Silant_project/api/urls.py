from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import (
    MachineViewSet, MaintenanceViewSet, ComplaintViewSet,
    index, dashboard, get_machines_for_select,
    get_users_by_group, get_users_for_select
)

router = DefaultRouter()
router.register(r'machines', MachineViewSet)
router.register(r'maintenances', MaintenanceViewSet)
router.register(r'complaints', ComplaintViewSet)

urlpatterns = [
    path('', include(router.urls)),
    path('machines/search/', MachineViewSet.as_view({'get': 'search'})),
    path('machines-for-select/', get_machines_for_select, name='machines-for-select'),
    path('users-by-group/', get_users_by_group, name='users-by-group'),
    path('users-for-select/', get_users_for_select, name='users-for-select'),
]