from rest_framework import permissions


class IsGuest(permissions.BasePermission):
    def has_permission(self, request, view):
        return not request.user.is_authenticated


class IsClient(permissions.BasePermission):
    def has_permission(self, request, view):
        return request.user.is_authenticated and request.user.groups.filter(name='Клиент').exists()


class IsServiceCompany(permissions.BasePermission):
    def has_permission(self, request, view):
        return request.user.is_authenticated and request.user.groups.filter(name='Сервисная компания').exists()


class IsManager(permissions.BasePermission):
    def has_permission(self, request, view):
        return request.user.is_authenticated and request.user.groups.filter(name='Менеджер').exists()


class MachinePermissions(permissions.BasePermission):
    def has_object_permission(self, request, view, obj):
        user = request.user

        if not user.is_authenticated:
            return False

        if user.groups.filter(name='Менеджер').exists():
            return True

        if user.groups.filter(name='Клиент').exists():
            return obj.client == user

        if user.groups.filter(name='Сервисная компания').exists():
            return obj.service_company == user

        return False

    def has_permission(self, request, view):
        if view.action in ['list', 'retrieve', 'search']:
            return True

        if not request.user.is_authenticated:
            return False

        if view.action == 'create':
            return request.user.groups.filter(name='Менеджер').exists()

        return True


class MaintenancePermissions(permissions.BasePermission):
    def has_object_permission(self, request, view, obj):
        user = request.user

        if not user.is_authenticated:
            return False

        if user.groups.filter(name='Менеджер').exists():
            return True

        if user.groups.filter(name='Клиент').exists():
            return obj.machine.client == user

        if user.groups.filter(name='Сервисная компания').exists():
            return obj.service_company == user

        return False

    def has_permission(self, request, view):
        if view.action in ['list', 'retrieve']:
            return request.user.is_authenticated

        if not request.user.is_authenticated:
            return False

        if view.action == 'create':
            return request.user.groups.filter(
                name__in=['Клиент', 'Сервисная компания', 'Менеджер']
            ).exists()

        if view.action in ['update', 'partial_update']:
            return request.user.groups.filter(
                name__in=['Сервисная компания', 'Менеджер']
            ).exists()

        if view.action == 'destroy':
            return request.user.groups.filter(name='Менеджер').exists()

        return True


class ComplaintPermissions(permissions.BasePermission):
    def has_object_permission(self, request, view, obj):
        user = request.user

        if not user.is_authenticated:
            return False

        if user.groups.filter(name='Менеджер').exists():
            return True

        if user.groups.filter(name='Клиент').exists():
            return obj.machine.client == user

        if user.groups.filter(name='Сервисная компания').exists():
            return obj.service_company == user

        return False

    def has_permission(self, request, view):
        if view.action in ['list', 'retrieve']:
            return request.user.is_authenticated

        if not request.user.is_authenticated:
            return False

        if view.action == 'create':
            return request.user.groups.filter(
                name__in=['Сервисная компания', 'Менеджер']
            ).exists()

        if view.action in ['update', 'partial_update']:
            return request.user.groups.filter(
                name__in=['Сервисная компания', 'Менеджер']
            ).exists()

        if view.action == 'destroy':
            return request.user.groups.filter(name='Менеджер').exists()

        return True