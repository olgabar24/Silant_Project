from django.shortcuts import render, get_object_or_404
from django.contrib.auth.decorators import login_required
from rest_framework import viewsets, status
from rest_framework.decorators import action, api_view
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from django_filters.rest_framework import DjangoFilterBackend
from django.contrib.auth.models import User, Group
from .models import Machine, Maintenance, Complaint
from .serializers import MachineSerializer, MachineGuestSerializer, MaintenanceSerializer, ComplaintSerializer
from .permissions import MachinePermissions, MaintenancePermissions, ComplaintPermissions
from .filters import MachineFilter, MaintenanceFilter, ComplaintFilter


def index(request):
    return render(request, 'index.html')


@login_required
def dashboard(request):
    user = request.user
    context = {
        'user': user,
        'is_manager': user.groups.filter(name='Менеджер').exists(),
        'is_client': user.groups.filter(name='Клиент').exists(),
        'is_service': user.groups.filter(name='Сервисная компания').exists(),
    }
    return render(request, 'dashboard.html', context)


class MachineViewSet(viewsets.ModelViewSet):
    queryset = Machine.objects.all()
    filter_backends = [DjangoFilterBackend]
    filterset_class = MachineFilter
    permission_classes = [MachinePermissions]

    def get_serializer_class(self):
        if self.request.user.is_authenticated:
            return MachineSerializer
        return MachineGuestSerializer

    def get_queryset(self):
        user = self.request.user

        if not user.is_authenticated:
            return Machine.objects.none()

        if user.groups.filter(name='Менеджер').exists():
            return Machine.objects.all()

        if user.groups.filter(name='Клиент').exists():
            return Machine.objects.filter(client=user)

        if user.groups.filter(name='Сервисная компания').exists():
            return Machine.objects.filter(service_company=user)

        return Machine.objects.none()

    @action(detail=False, methods=['get'], permission_classes=[MachinePermissions])
    def search(self, request):
        factory_number = request.query_params.get('factory_number', '')
        if factory_number:
            try:
                machine = Machine.objects.get(factory_number=factory_number)

                if not request.user.is_authenticated:
                    serializer = MachineGuestSerializer(machine)
                    return Response(serializer.data)

                if machine.client == request.user or \
                        machine.service_company == request.user or \
                        request.user.groups.filter(name='Менеджер').exists():
                    serializer = MachineSerializer(machine)
                    return Response(serializer.data)
                else:
                    serializer = MachineGuestSerializer(machine)
                    return Response(serializer.data)

            except Machine.DoesNotExist:
                return Response(
                    {'error': 'Машина с таким заводским номером не найдена'},
                    status=status.HTTP_404_NOT_FOUND
                )
        return Response(
            {'error': 'Введите заводской номер'},
            status=status.HTTP_400_BAD_REQUEST
        )


class MaintenanceViewSet(viewsets.ModelViewSet):
    queryset = Maintenance.objects.all()
    serializer_class = MaintenanceSerializer
    filter_backends = [DjangoFilterBackend]
    filterset_class = MaintenanceFilter
    permission_classes = [MaintenancePermissions]

    def get_queryset(self):
        user = self.request.user

        if not user.is_authenticated:
            return Maintenance.objects.none()

        if user.groups.filter(name='Менеджер').exists():
            return Maintenance.objects.all()

        if user.groups.filter(name='Клиент').exists():
            return Maintenance.objects.filter(machine__client=user)

        if user.groups.filter(name='Сервисная компания').exists():
            return Maintenance.objects.filter(service_company=user)

        return Maintenance.objects.none()


class ComplaintViewSet(viewsets.ModelViewSet):
    queryset = Complaint.objects.all()
    serializer_class = ComplaintSerializer
    filter_backends = [DjangoFilterBackend]
    filterset_class = ComplaintFilter
    permission_classes = [ComplaintPermissions]

    def get_queryset(self):
        user = self.request.user

        if not user.is_authenticated:
            return Complaint.objects.none()

        if user.groups.filter(name='Менеджер').exists():
            return Complaint.objects.all()

        if user.groups.filter(name='Клиент').exists():
            return Complaint.objects.filter(machine__client=user)

        if user.groups.filter(name='Сервисная компания').exists():
            return Complaint.objects.filter(service_company=user)

        return Complaint.objects.none()


@api_view(['GET'])
def get_machines_for_select(request):
    """API для получения списка машин для выпадающих списков"""
    user = request.user

    if not user.is_authenticated:
        return Response([])

    if user.groups.filter(name='Менеджер').exists():
        machines = Machine.objects.all()
    elif user.groups.filter(name='Клиент').exists():
        machines = Machine.objects.filter(client=user)
    elif user.groups.filter(name='Сервисная компания').exists():
        machines = Machine.objects.filter(service_company=user)
    else:
        machines = Machine.objects.none()

    data = [{
        'id': machine.id,
        'factory_number': machine.factory_number,
        'technique_model': machine.technique_model,
        'client_username': machine.client.username if machine.client else '',
        'service_company_username': machine.service_company.username if machine.service_company else ''
    } for machine in machines]

    return Response(data)


@api_view(['GET'])
def get_users_by_group(request):
    """API для получения пользователей по группам"""
    user = request.user

    if not user.is_authenticated or not user.groups.filter(name='Менеджер').exists():
        return Response({'error': 'Доступ запрещен'}, status=403)

    group_name = request.GET.get('group', '')
    users_data = []

    if group_name:
        try:
            group = Group.objects.get(name=group_name)
            users = group.user_set.all()
            users_data = [{
                'id': u.id,
                'username': u.username,
                'email': u.email,
                'first_name': u.first_name,
                'last_name': u.last_name,
                'date_joined': u.date_joined.strftime('%Y-%m-%d %H:%M:%S') if u.date_joined else ''
            } for u in users]
        except Group.DoesNotExist:
            pass
    else:
        # Все пользователи
        users = User.objects.all()
        users_data = [{
            'id': u.id,
            'username': u.username,
            'email': u.email,
            'groups': list(u.groups.values_list('name', flat=True)),
            'date_joined': u.date_joined.strftime('%Y-%m-%d %H:%M:%S') if u.date_joined else ''
        } for u in users]

    return Response(users_data)


@api_view(['GET'])
def get_users_for_select(request):
    """API для получения пользователей для выпадающих списков"""
    user = request.user

    if not user.is_authenticated:
        return Response([])

    group_name = request.GET.get('group', '')
    users_data = []

    if group_name:
        try:
            group = Group.objects.get(name=group_name)
            users = group.user_set.all()
            users_data = [{
                'id': u.id,
                'username': u.username,
                'full_name': f"{u.first_name} {u.last_name}".strip() or u.username
            } for u in users]
        except Group.DoesNotExist:
            pass

    return Response(users_data)