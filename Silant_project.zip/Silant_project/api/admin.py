from django.contrib import admin
from .models import Machine, Maintenance, Complaint

@admin.register(Machine)
class MachineAdmin(admin.ModelAdmin):
    list_display = ['factory_number', 'technique_model', 'engine_model', 'client', 'service_company']
    list_filter = ['technique_model', 'engine_model']
    search_fields = ['factory_number', 'engine_number', 'transmission_number']

@admin.register(Maintenance)
class MaintenanceAdmin(admin.ModelAdmin):
    list_display = ['machine', 'type', 'date', 'operating_time', 'company']
    list_filter = ['type', 'date']
    search_fields = ['order_number', 'machine__factory_number']

@admin.register(Complaint)
class ComplaintAdmin(admin.ModelAdmin):
    list_display = ['machine', 'failure_node', 'failure_date', 'recovery_date', 'downtime']
    list_filter = ['failure_node', 'failure_date']
    search_fields = ['failure_description', 'machine__factory_number']