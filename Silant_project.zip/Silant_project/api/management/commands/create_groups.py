from django.core.management.base import BaseCommand
from django.contrib.auth.models import Group, Permission
from django.contrib.contenttypes.models import ContentType
from api.models import Machine, Maintenance, Complaint


class Command(BaseCommand):
    help = 'Создает группы пользователей и назначает права'

    def handle(self, *args, **options):
        # Создаем группы
        groups_data = {
            'Клиент': {
                Machine: ['view'],
                Maintenance: ['view', 'add'],
                Complaint: ['view'],
            },
            'Сервисная компания': {
                Machine: ['view'],
                Maintenance: ['view', 'add', 'change'],
                Complaint: ['view', 'add', 'change'],
            },
            'Менеджер': {
                Machine: ['add', 'change', 'delete', 'view'],
                Maintenance: ['add', 'change', 'delete', 'view'],
                Complaint: ['add', 'change', 'delete', 'view'],
            }
        }

        for group_name, models_perms in groups_data.items():
            group, created = Group.objects.get_or_create(name=group_name)
            if created:
                self.stdout.write(f'Создана группа: {group_name}')

            # Очищаем старые права
            group.permissions.clear()

            # Добавляем новые права для каждой модели
            for model, perms in models_perms.items():
                content_type = ContentType.objects.get_for_model(model)

                for perm in perms:
                    try:
                        # Используем встроенные permissions Django
                        permission = Permission.objects.get(
                            codename=f'{perm}_{model._meta.model_name}',
                            content_type=content_type
                        )
                        group.permissions.add(permission)
                        self.stdout.write(f'  Добавлено право: {perm}_{model._meta.model_name}')
                    except Permission.DoesNotExist:
                        self.stdout.write(f'  Ошибка: право {perm}_{model._meta.model_name} не найдено')

            self.stdout.write(f'Права назначены для группы: {group_name}\n')

        self.stdout.write(self.style.SUCCESS('Все группы созданы и права назначены!'))