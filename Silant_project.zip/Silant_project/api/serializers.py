from rest_framework import serializers
from .models import Machine, Maintenance, Complaint


class MachineSerializer(serializers.ModelSerializer):
    client_username = serializers.CharField(source='client.username', read_only=True)
    service_company_username = serializers.CharField(source='service_company.username', read_only=True)

    class Meta:
        model = Machine
        fields = '__all__'
        read_only_fields = ['id']


class MachineGuestSerializer(serializers.ModelSerializer):
    class Meta:
        model = Machine
        fields = [
            'factory_number',
            'technique_model',
            'engine_model',
            'engine_number',
            'transmission_model',
            'transmission_number',
            'driving_bridge_model',
            'driving_bridge_number',
            'controlled_bridge_model',
            'controlled_bridge_number',
        ]


class MaintenanceSerializer(serializers.ModelSerializer):
    machine_factory_number = serializers.CharField(source='machine.factory_number', read_only=True)
    service_company_username = serializers.CharField(source='service_company.username', read_only=True)

    class Meta:
        model = Maintenance
        fields = '__all__'
        read_only_fields = ['id']


class ComplaintSerializer(serializers.ModelSerializer):
    machine_factory_number = serializers.CharField(source='machine.factory_number', read_only=True)
    service_company_username = serializers.CharField(source='service_company.username', read_only=True)

    class Meta:
        model = Complaint
        fields = '__all__'
        read_only_fields = ['id', 'downtime']