from django.db import models
from django.contrib.auth.models import User


class Machine(models.Model):
    factory_number = models.CharField(max_length=50, unique=True, verbose_name="Заводской номер")
    technique_model = models.CharField(max_length=100, verbose_name="Модель техники")
    engine_model = models.CharField(max_length=100, verbose_name="Модель двигателя")
    engine_number = models.CharField(max_length=50, verbose_name="Зав. № двигателя")
    transmission_model = models.CharField(max_length=100, verbose_name="Модель трансмиссии")
    transmission_number = models.CharField(max_length=50, verbose_name="Зав. № трансмиссии")
    driving_bridge_model = models.CharField(max_length=100, verbose_name="Модель ведущего моста")
    driving_bridge_number = models.CharField(max_length=50, verbose_name="Зав. № ведущего моста")
    controlled_bridge_model = models.CharField(max_length=100, verbose_name="Модель управляемого моста")
    controlled_bridge_number = models.CharField(max_length=50, verbose_name="Зав. № управляемого моста")

    # Дополнительные поля
    delivery_contract = models.CharField(max_length=255, verbose_name="Договор поставки №, дата", blank=True)
    shipment_date = models.DateField(verbose_name="Дата отгрузки с завода", null=True, blank=True)
    consignee = models.CharField(max_length=255, verbose_name="Грузополучатель", blank=True)
    delivery_address = models.TextField(verbose_name="Адрес поставки", blank=True)
    equipment = models.TextField(verbose_name="Комплектация (доп. опции)", blank=True)

    # Связи с пользователями (только из соответствующих групп)
    client = models.ForeignKey(
        User,
        on_delete=models.PROTECT,
        verbose_name="Клиент",
        related_name='client_machines',
        limit_choices_to={'groups__name': 'Клиент'},
        null=True,
        blank=True
    )

    service_company = models.ForeignKey(
        User,
        on_delete=models.PROTECT,
        verbose_name="Сервисная компания",
        related_name='service_machines',
        limit_choices_to={'groups__name': 'Сервисная компания'},
        null=True,
        blank=True
    )

    class Meta:
        verbose_name = "Машина"
        verbose_name_plural = "Машины"
        ordering = ['factory_number']

    def __str__(self):
        return f"{self.technique_model} - {self.factory_number}"

    def get_absolute_url(self):
        return f"/machine/{self.id}/"


class Maintenance(models.Model):
    machine = models.ForeignKey(
        Machine,
        on_delete=models.CASCADE,
        related_name='maintenances',
        verbose_name="Машина"
    )
    type = models.CharField(max_length=100, verbose_name="Вид ТО")
    date = models.DateField(verbose_name="Дата проведения ТО")
    operating_time = models.PositiveIntegerField(verbose_name="Наработка, м/час")
    order_number = models.CharField(max_length=50, verbose_name="№ заказ-наряда")
    order_date = models.DateField(verbose_name="Дата заказ-наряда")
    company = models.CharField(max_length=200, verbose_name="Организация, проводившая ТО")

    service_company = models.ForeignKey(
        User,
        on_delete=models.PROTECT,
        verbose_name="Сервисная компания",
        limit_choices_to={'groups__name': 'Сервисная компания'},
        null=True,
        blank=True
    )

    class Meta:
        verbose_name = "Техническое обслуживание"
        verbose_name_plural = "Технические обслуживания"
        ordering = ['-date']

    def __str__(self):
        return f"{self.machine.factory_number} - {self.type} - {self.date}"


class Complaint(models.Model):
    machine = models.ForeignKey(
        Machine,
        on_delete=models.CASCADE,
        related_name='complaints',
        verbose_name="Машина"
    )
    failure_date = models.DateField(verbose_name="Дата отказа")
    operating_time = models.PositiveIntegerField(verbose_name="Наработка, м/час")
    failure_node = models.CharField(max_length=100, verbose_name="Узел отказа")
    failure_description = models.TextField(verbose_name="Описание отказа")
    recovery_method = models.CharField(max_length=100, verbose_name="Способ восстановления")
    spare_parts = models.TextField(verbose_name="Используемые запасные части", blank=True)
    recovery_date = models.DateField(verbose_name="Дата восстановления")
    downtime = models.PositiveIntegerField(verbose_name="Время простоя техники", editable=False)

    service_company = models.ForeignKey(
        User,
        on_delete=models.PROTECT,
        verbose_name="Сервисная компания",
        limit_choices_to={'groups__name': 'Сервисная компания'},
        null=True,
        blank=True
    )

    class Meta:
        verbose_name = "Рекламация"
        verbose_name_plural = "Рекламации"
        ordering = ['-failure_date']

    def __str__(self):
        return f"{self.machine.factory_number} - {self.failure_date}"

    def save(self, *args, **kwargs):
        if self.recovery_date and self.failure_date:
            delta = self.recovery_date - self.failure_date
            self.downtime = delta.days
        super().save(*args, **kwargs)