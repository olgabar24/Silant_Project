import django_filters
from .models import Machine, Maintenance, Complaint


class MachineFilter(django_filters.FilterSet):
    technique_model = django_filters.CharFilter(lookup_expr='icontains')
    engine_model = django_filters.CharFilter(lookup_expr='icontains')
    transmission_model = django_filters.CharFilter(lookup_expr='icontains')
    driving_bridge_model = django_filters.CharFilter(lookup_expr='icontains')
    controlled_bridge_model = django_filters.CharFilter(lookup_expr='icontains')

    class Meta:
        model = Machine
        fields = {
            'factory_number': ['exact'],
            'technique_model': ['exact'],
            'engine_model': ['exact'],
            'transmission_model': ['exact'],
            'driving_bridge_model': ['exact'],
            'controlled_bridge_model': ['exact'],
        }


class MaintenanceFilter(django_filters.FilterSet):
    type = django_filters.CharFilter(lookup_expr='icontains')
    machine__factory_number = django_filters.CharFilter(field_name='machine__factory_number')
    service_company__username = django_filters.CharFilter(field_name='service_company__username')

    class Meta:
        model = Maintenance
        fields = ['type', 'machine__factory_number', 'service_company__username']


class ComplaintFilter(django_filters.FilterSet):
    failure_node = django_filters.CharFilter(lookup_expr='icontains')
    recovery_method = django_filters.CharFilter(lookup_expr='icontains')
    service_company__username = django_filters.CharFilter(field_name='service_company__username')

    class Meta:
        model = Complaint
        fields = ['failure_node', 'recovery_method', 'service_company__username']